package taller.constructores;

public class Paquete {

    private String codigo;
    private String destino;
    private double peso;
    private boolean asegurado;

    // Constructor completo
    public Paquete(String codigo, String destino, double peso, boolean asegurado) {
        this.codigo = codigo;
        this.destino = destino;
        this.peso = peso;
        this.asegurado = asegurado;
    }

    // Constructor con código y destino
    public Paquete(String codigo, String destino) {
        this(codigo, destino, 1.0, false);
    }

    // Constructor solo con código
    public Paquete(String codigo) {
        this(codigo, "Por asignar");
    }
    
    
    
    
    
    
    

    // Mostrar información sin parámetros
    public void mostrarInformacion() {
        System.out.println("Código: " + codigo);
        System.out.println("Destino: " + destino);
        System.out.println("Peso: " + peso + " kg");
        System.out.println("Asegurado: " + asegurado);
    }

    // NUEVO: sobrecarga de mostrarInformacion
    public void mostrarInformacion(String encabezado) {
        System.out.println(encabezado);
        mostrarInformacion();
    }

    // Actualizar peso
    public void actualizarPeso(double peso) {
        this.peso = peso;
    }

    // Calcular costo
    public double calcularCosto() {
        double costo = peso * 5000;

        if (asegurado) {
            costo += 8000;
        }

        return costo;
    }

    // Sobrecarga de calcularCosto
    public double calcularCosto(double tarifaPorKilo) {
        double costo = peso * tarifaPorKilo;

        if (asegurado) {
            costo += 8000;
        }

        return costo;
    }

    // Determinar si es pesado
    public boolean esPesado() {
        return peso > 5;
    }
}
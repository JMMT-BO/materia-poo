package taller.constructores;

public class Envio {

    public static void main(String[] args) {

        Paquete p1 = new Paquete("P-001", "Manizales", 3.0, true);
        Paquete p2 = new Paquete("P-002", "Bogotá", 6.0, false);
        Paquete p3 = new Paquete("P-003", "Medellín", 8.0, true);

        p1.mostrarInformacion("Información del paquete p1:");

        System.out.println();

        p2.mostrarInformacion("Información del paquete p2:");

        System.out.println();

        p3.mostrarInformacion("Información del paquete p3:");
    }
}
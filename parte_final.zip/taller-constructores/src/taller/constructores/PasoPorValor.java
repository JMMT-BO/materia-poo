/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller.constructores;

/**
 *
 * @author PC
 */
public class PasoPorValor {

    public static void modificar(double numero) {
        numero = 1000;
        System.out.println("Valor dentro del método: " + numero);
    }

    public static void main(String[] args) {

        double original = 50;

        System.out.println("Valor antes del método: " + original);

        modificar(original);

        System.out.println("Valor después del método: " + original);
    }
}
    
